if (typeof(JoomlaShine.jQuery) == 'function'){
	JoomlaShine.jQuery.noConflict();
}