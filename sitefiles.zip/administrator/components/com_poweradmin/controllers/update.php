<?php
/**
 * @author    JoomlaShine.com
 * @copyright JoomlaShine.com
 * @link      http://joomlashine.com/
 * @package   JSN Poweradmin
 * @version   $Id: update.php 14709 2012-07-31 10:21:07Z cuongnm $
 * @license   GNU/GPL v2 http://www.gnu.org/licenses/gpl-2.0.html
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Update controller of JSN Poweradmin component
 */
class PowerAdminControllerUpdate extends JSNUpdateController
{
}
